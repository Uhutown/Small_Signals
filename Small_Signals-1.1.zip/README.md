This ContentPack adds small signals to the Mod Open-Signals!

<img width="1920" height="1009" alt="2026-02-09_13 44 34" src="https://github.com/user-attachments/assets/a5ed025e-94c7-4f4e-9f4e-d7178f79fa9a" />
